﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrchestraBookingTicketsApp.ViewModels.OrchestraModel
{
    public class BuyTicketViewModel
    {
        public int OrchestraId { get; set; }
        public int SeatNumber { get; set; }
    }
}
