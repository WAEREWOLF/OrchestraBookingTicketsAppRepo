﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OrchestraBookingTicketsApp.ViewModels.LeadArtistModel
{
    public class AddLeadArtistViewModel
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public int OrchestraId { get; set; }
    }
}
